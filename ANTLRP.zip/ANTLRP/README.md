				ARDUINOLITE

En este proyecto se realizará un análisis léxico y sintáctico a partir de una gramática diseñada para simplificar funciones escritas en Arduino, permitiendo identificar su estructura y facilitar su optimización.

INFORMACION DEL CURSO:

		PROGRAMACION DE SISTEMAS DE BASE 1

		UNIVERSIDAD AUTONOMA DE TAMAULIPAS 

		OCTAVO SEMETRES DE 2025

		Muñoz Quintero Dante Adolfo

INTEGRANTES:

		Lorenzo Sanches Lexiss

		Perez Cristino Victor Alejandro

		Juarez Beltran Eduardo Moises

		De La Cruz Marquez Rodrigo
